# Smart Edu AI — Local Backend + Gemini

Minimal Node/Express backend: `db.json` saqlash, frontend, rasm yuklash va **Google Gemini** orqali rasm tekshirish.

## Tezkor start

```bash
npm install
```

### 1) Gemini API kalit (bepul)

1. Ochish: https://aistudio.google.com/apikey  
2. **Create API key** → kalitni nusxalang (`AIza...`)

### 2) Serverni ishga tushirish

**Windows PowerShell:**
```powershell
$env:GEMINI_API_KEY = "AIza_SIZNING_KALITINGIZ"
npm start
```

**Windows CMD:**
```cmd
set GEMINI_API_KEY=AIza_SIZNING_KALITINGIZ
npm start
```

**Linux / macOS:**
```bash
export GEMINI_API_KEY=AIza_SIZNING_KALITINGIZ
npm start
```

Brauzer: http://localhost:3000

### 3) AI ishlayotganini tekshirish

http://localhost:3000/api/ai-status  

`"configured": true` bo‘lsa — tayyor.

## Ilovada qanday ishlatiladi

1. Tizimga kiring (o‘qituvchi)
2. Ish yozuvi yonidagi **AI tekshir** (yulduzcha) — rasm tanlang
3. Yoki avval **Rasm qo‘shish**, keyin **AI baho olish**
4. AI ball va izoh beradi → **Qabul qilish** bilan bahoni saqlashingiz mumkin

## API

| Method | Path | Vazifa |
|--------|------|--------|
| GET | `/api/ping` | Server tirikmi |
| GET | `/api/db` | Bazani o‘qish |
| POST | `/api/db` | Bazani saqlash |
| POST | `/api/upload-image` | Rasm yuklash (`image` field) |
| POST | `/api/check-image` | Gemini bilan rasm tekshirish |
| GET | `/api/ai-status` | Gemini sozlanganmi |

## Muhit o‘zgaruvchilari

| Nom | Majburiy | Tavsif |
|-----|----------|--------|
| `GEMINI_API_KEY` | Ha (AI uchun) | Google AI Studio kaliti |
| `GEMINI_MODEL` | Yo‘q | Default: `gemini-2.0-flash` |
| `PORT` | Yo‘q | Default: `3000` |

## Eslatma

- Rasmlar `uploads/` papkasiga saqlanadi
- Ma’lumotlar `db.json` da
- Backend ishlamasa frontend `localStorage` ga o‘tadi (AI ishlamaydi)
