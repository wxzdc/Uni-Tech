const express = require('express');
const fs = require('fs');
const path = require('path');
const cors = require('cors');
const multer = require('multer');

const DB_FILE = path.join(__dirname, 'db.json');
const DEFAULT_DB = {
  users: [],
  profile: { name: "O'qituvchi", role: "O'qituvchi" },
  subjects: [],
  students: [],
  assignments: [],
  submissions: [],
  auth: null,
  lang: "uz",
  seenAt: null
};
const PORT = process.env.PORT || 3000;
const app = express();
app.use(cors());
app.use(express.json({ limit: '15mb' }));
app.use(express.static(path.join(__dirname)));

if (!fs.existsSync(DB_FILE)) {
  fs.writeFileSync(DB_FILE, JSON.stringify(DEFAULT_DB, null, 2), 'utf8');
}

const UPLOADS = path.join(__dirname, 'uploads');
if (!fs.existsSync(UPLOADS)) fs.mkdirSync(UPLOADS);
app.use('/uploads', express.static(UPLOADS));

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOADS),
  filename: (req, file, cb) => cb(null, Date.now() + '-' + file.originalname.replace(/\s+/g, '_'))
});
const upload = multer({
  storage,
  limits: { fileSize: 8 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    if (/^image\//.test(file.mimetype)) cb(null, true);
    else cb(new Error('Faqat rasm fayllari'));
  }
});

app.get('/api/ping', (req, res) => res.sendStatus(200));

app.get('/api/db', (req, res) => {
  fs.readFile(DB_FILE, 'utf8', (err, data) => {
    if (err) return res.json({});
    try { return res.json(JSON.parse(data)); } catch (e) { return res.json({}); }
  });
});

app.post('/api/db', (req, res) => {
  const payload = req.body || {};
  fs.writeFile(DB_FILE, JSON.stringify(payload, null, 2), 'utf8', (err) => {
    if (err) return res.status(500).json({ ok: false, error: String(err) });
    return res.json({ ok: true });
  });
});

app.post('/api/upload-image', upload.single('image'), (req, res) => {
  if (!req.file) return res.status(400).json({ ok: false, error: 'no_file' });
  const url = `/uploads/${req.file.filename}`;
  return res.json({ ok: true, url });
});

/** Rasmni lokal fayldan base64 + mime qilib olish */
function loadImageAsBase64(imageUrl) {
  if (!imageUrl) return null;
  // /uploads/xxx yoki to'liq URL
  let filename = null;
  try {
    if (imageUrl.startsWith('/uploads/')) {
      filename = path.basename(imageUrl);
    } else if (imageUrl.includes('/uploads/')) {
      filename = path.basename(new URL(imageUrl).pathname);
    } else {
      filename = path.basename(imageUrl);
    }
  } catch (e) {
    filename = path.basename(String(imageUrl));
  }
  const filePath = path.join(UPLOADS, filename);
  if (!fs.existsSync(filePath)) return null;
  const buf = fs.readFileSync(filePath);
  const ext = path.extname(filePath).toLowerCase();
  const mime =
    ext === '.png' ? 'image/png' :
    ext === '.webp' ? 'image/webp' :
    ext === '.gif' ? 'image/gif' :
    'image/jpeg';
  return { mime, data: buf.toString('base64') };
}

/**
 * Google Gemini — rasm tekshirish
 * Env: GEMINI_API_KEY (majburiy)
 * Ixtiyoriy: GEMINI_MODEL (default: gemini-2.5-flash)
 */
async function callGemini({ image, prompt }) {
  const apiKey = String(process.env.GEMINI_API_KEY || process.env.GOOGLE_API_KEY || '').trim();
  if (!apiKey) {
    const err = new Error('GEMINI_API_KEY_NOT_SET');
    err.code = 'NO_KEY';
    throw err;
  }

  const models = [
    process.env.GEMINI_MODEL,
    'gemini-2.5-flash',
    'gemini-2.5-flash-lite',
    'gemini-3.1-flash-lite',
    'gemini-3.6-flash',
    'gemini-3.5-flash'
  ].filter(Boolean);
  const tryModels = [...new Set(models)];

  const parts = [];
  if (prompt) parts.push({ text: prompt });
  if (image && image.data) {
    parts.push({
      inline_data: {
        mime_type: image.mime || 'image/jpeg',
        data: image.data
      }
    });
  }

  const body = {
    contents: [{ role: 'user', parts }],
    generationConfig: { temperature: 0.2, maxOutputTokens: 1024 }
  };

  let lastErr = null;
  for (const model of tryModels) {
    const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`;
    try {
      // Header
      let resp = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-goog-api-key': apiKey
        },
        body: JSON.stringify(body)
      });
      let json = await resp.json();
      if (resp.ok) {
        const text = (json.candidates && json.candidates[0] && json.candidates[0].content && json.candidates[0].content.parts)
          ? json.candidates[0].content.parts.map(p => p.text || '').join('') : '';
        return { text, raw: json, model, provider: 'gemini' };
      }
      // Query param fallback
      resp = await fetch(url + '?key=' + encodeURIComponent(apiKey), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      });
      json = await resp.json();
      if (resp.ok) {
        const text = (json.candidates && json.candidates[0] && json.candidates[0].content && json.candidates[0].content.parts)
          ? json.candidates[0].content.parts.map(p => p.text || '').join('') : '';
        return { text, raw: json, model, provider: 'gemini' };
      }
      lastErr = (json.error && json.error.message) || JSON.stringify(json);
      if (resp.status === 404) continue;
      if (resp.status === 400 || resp.status === 401 || resp.status === 403) break;
    } catch (e) {
      lastErr = e.message || String(e);
    }
  }

  const err = new Error(lastErr || 'Gemini so‘rovi muvaffaqiyatsiz');
  err.code = 'AUTH';
  throw err;
}

/** OpenRouter — bepul vision (Gemini AQ. kalit ishlamasa) */
async function callOpenRouter({ image, prompt }) {
  const apiKey = String(process.env.OPENROUTER_API_KEY || '').trim();
  if (!apiKey) {
    const err = new Error('OPENROUTER_API_KEY_NOT_SET');
    err.code = 'NO_KEY';
    throw err;
  }
  const model = process.env.OPENROUTER_MODEL || 'qwen/qwen2.5-vl-72b-instruct:free';
  const content = [];
  if (prompt) content.push({ type: 'text', text: prompt });
  if (image && image.data) {
    content.push({
      type: 'image_url',
      image_url: { url: `data:${image.mime || 'image/jpeg'};base64,${image.data}` }
    });
  }
  const resp = await fetch('https://openrouter.ai/api/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + apiKey,
      'HTTP-Referer': 'http://localhost:3000',
      'X-Title': 'UniTeach Smart Edu'
    },
    body: JSON.stringify({
      model,
      messages: [{ role: 'user', content }],
      temperature: 0.2,
      max_tokens: 1024
    })
  });
  const json = await resp.json();
  if (!resp.ok) {
    const msg = (json.error && (json.error.message || json.error)) || JSON.stringify(json);
    const err = new Error(String(msg));
    err.code = 'OPENROUTER_HTTP';
    throw err;
  }
  const text = (json.choices && json.choices[0] && json.choices[0].message && json.choices[0].message.content) || '';
  return { text, raw: json, model, provider: 'openrouter' };
}

async function callAI({ image, prompt }) {
  const prefer = (process.env.AI_PROVIDER || 'auto').toLowerCase();
  const hasGemini = !!(process.env.GEMINI_API_KEY || process.env.GOOGLE_API_KEY);
  const hasOR = !!process.env.OPENROUTER_API_KEY;

  if (prefer === 'openrouter' && hasOR) return callOpenRouter({ image, prompt });
  if (prefer === 'gemini' && hasGemini) return callGemini({ image, prompt });

  // auto: Gemini sinab, ishlamasa OpenRouter
  if (hasGemini) {
    try {
      return await callGemini({ image, prompt });
    } catch (e) {
      if (hasOR) {
        console.warn('Gemini failed, fallback OpenRouter:', e.message);
        return callOpenRouter({ image, prompt });
      }
      throw e;
    }
  }
  if (hasOR) return callOpenRouter({ image, prompt });

  const err = new Error('GEMINI_API_KEY_NOT_SET');
  err.code = 'NO_KEY';
  throw err;
}

/** AI javobidan suggestedScore va comment ajratib olish */
function parseGradeResponse(text, maxScore) {
  const max = Number(maxScore) || 100;
  let suggestedScore = null;
  let comment = text || '';

  // JSON qidirish
  const jsonMatch = text.match(/\{[\s\S]*?\}/);
  if (jsonMatch) {
    try {
      const obj = JSON.parse(jsonMatch[0]);
      if (obj.suggestedScore != null) suggestedScore = Number(obj.suggestedScore);
      else if (obj.score != null) suggestedScore = Number(obj.score);
      if (obj.comment) comment = String(obj.comment);
      else if (obj.reason) comment = String(obj.reason);
      else if (obj.feedback) comment = String(obj.feedback);
    } catch (e) { /* ignore */ }
  }

  // "ball: 85" yoki "85/100" kabi
  if (suggestedScore == null) {
    const m1 = text.match(/(?:suggestedScore|score|ball|baho)\s*[:=]?\s*(\d{1,3})/i);
    const m2 = text.match(/(\d{1,3})\s*\/\s*\d{1,3}/);
    if (m1) suggestedScore = Number(m1[1]);
    else if (m2) suggestedScore = Number(m2[1]);
  }

  if (suggestedScore != null && !Number.isNaN(suggestedScore)) {
    suggestedScore = Math.max(0, Math.min(max, Math.round(suggestedScore)));
  } else {
    suggestedScore = null;
  }

  return { suggestedScore, comment: comment.trim(), text: text.trim() };
}

app.post('/api/check-image', async (req, res) => {
  const { imageUrl, prompt, submissionId, maxScore } = req.body || {};
  if (!imageUrl && !prompt) {
    return res.status(400).json({ ok: false, error: 'imageUrl yoki prompt kerak' });
  }

  const image = imageUrl ? loadImageAsBase64(imageUrl) : null;
  if (imageUrl && !image) {
    return res.status(400).json({ ok: false, error: 'Rasm topilmadi (uploads papkasida yo\'q)' });
  }

  const defaultPrompt =
    `Siz o'qituvchi yordamchisisiz. Talabaning daftar/ish rasmini ko'rib chiqing.\n` +
    `1) Rasmdagi yozuv/yechimni qisqa o'qing.\n` +
    `2) Xatolarni aniqlang.\n` +
    `3) 0 dan ${maxScore || 100} gacha ball taklif qiling.\n` +
    `Javobni FAQAT quyidagi JSON formatda bering (boshqa matn qo'shmang):\n` +
    `{"suggestedScore": 85, "comment": "Qisqa izoh o'zbek tilida"}`;

  const finalPrompt = prompt || defaultPrompt;

  try {
    const { text } = await callAI({ image, prompt: finalPrompt });
    const parsed = parseGradeResponse(text, maxScore || 100);
    return res.json({
      ok: true,
      result: {
        suggestedScore: parsed.suggestedScore,
        comment: parsed.comment,
        text: parsed.text,
        submissionId: submissionId || null
      }
    });
  } catch (e) {
    if (e.code === 'NO_KEY') {
      return res.status(500).json({
        ok: false,
        error: 'GEMINI_API_KEY_NOT_SET',
        hint: 'Serverni ishga tushirishdan oldin GEMINI_API_KEY o\'rnating. https://aistudio.google.com/apikey'
      });
    }
    console.error('Gemini error:', e.message);
    return res.status(500).json({ ok: false, error: String(e.message || e) });
  }
});

// AI holatini tekshirish
app.get('/api/ai-status', (req, res) => {
  const hasGemini = !!(process.env.GEMINI_API_KEY || process.env.GOOGLE_API_KEY);
  const hasOR = !!process.env.OPENROUTER_API_KEY;
  res.json({
    ok: true,
    configured: hasGemini || hasOR,
    gemini: hasGemini,
    openrouter: hasOR,
    model: hasOR && !hasGemini
      ? (process.env.OPENROUTER_MODEL || 'qwen/qwen2.5-vl-72b-instruct:free')
      : (process.env.GEMINI_MODEL || 'gemini-2.5-flash'),
    provider: hasGemini ? 'google-gemini' : (hasOR ? 'openrouter' : 'none')
  });
});

app.listen(PORT, () => {
  const hasGemini = !!(process.env.GEMINI_API_KEY || process.env.GOOGLE_API_KEY);
  const hasOR = !!process.env.OPENROUTER_API_KEY;
  console.log(`Server: http://localhost:${PORT}`);
  if (hasGemini) console.log(`Gemini: ULANGAN (model: ${process.env.GEMINI_MODEL || 'gemini-2.5-flash'})`);
  else console.log(`Gemini: KALIT YO'Q yoki AQ. kalit ishlamasligi mumkin`);
  if (hasOR) console.log(`OpenRouter: ULANGAN (zaxira AI)`);
  else console.log(`OpenRouter: yo'q — https://openrouter.ai/keys dan bepul kalit oling`);
  if (!hasGemini && !hasOR) console.log(`DIQQAT: hech qanday AI kaliti yo'q`);
});
